import { useState, useEffect } from "react";
import axios from "../request/axios";
import { Select } from "antd";
import { Chart } from "react-google-charts";

// import MaterialTable from "material-table";
import { useNavigate } from "react-router-dom";

const { Option } = Select;
// import { Link } from "react-router-dom";
export default function Dashboard() {
  const [summary, setSummary] = useState([]);
  const [tran, setTran] = useState([]);
  const [tic, setTic] = useState([]);
  const [line, setLine] = useState([]);
  const [drop, setDrop] = useState([]);
  const nav = useNavigate();
  useEffect(() => {
    async function getSummary() {
      await axios
        .get("transaction-manager/v1/admin/dashboard/summary", {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("cityremit-token")
          }
        })
        .then((res) => {
          setSummary(res.data.data[0]);
        })
        .catch((e) => {
          nav("/");
        });
    }
    async function getCountry() {
      await axios
        .get("config/v1/admin/masters/country", {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("cityremit-token")
          }
        })
        .then((res) => {
          setDrop(res.data.data);
        })
        .catch((e) => {
          nav("/");
        });
    }
    async function getTransaction() {
      await axios
        .post("transaction-manager/v1/admin/dashboard/search", null, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("cityremit-token")
          }
        })
        .then((res) => {
          setTran(res.data.data);
        })
        .catch((e) => {
          nav("/");
        });
    }
    async function getTicket() {
      await axios
        .post("config/v1/tickets/search", null, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("cityremit-token")
          }
        })
        .then((res) => {
          setTic(res.data.data.data);
        })
        .catch((e) => {
          nav("/");
        });
    }
    getTicket();
    getTransaction();
    getSummary();
    getCountry();
  }, []);

  return (
    <div>
      <div className="main" style={{ backgroundColor: "rgb(234, 234, 234)" }}>
        <nav
          className="navbar"
          style={{ backgroundColor: "rgb(16, 186, 198)" }}
        >
          <div className="container-fluid">
            <img
              src="https://jp-dev.cityremit.global/static/media/city-express-icon-logo.7b8cd46f.png"
              style={{ height: 40, marginLeft: 20 }}
            />
            <img
              src={localStorage.getItem("cityremit-user-image")}
              style={{ height: 40, marginLeft: 850 }}
            />
            <span style={{ color: "white" }}>Krishna Prasad Timilsina</span>
          </div>
        </nav>
        <p style={{ marginLeft: 118, marginTop: 20, fontSize: 18 }}>
          Dashboard
        </p>
        <div
          className="container"
          style={{ display: "flex", justifyContent: "space-between" }}
        >
          <fieldset
            style={{
              backgroundColor: "white",
              width: 150,
              height: 200,
              borderRadius: 10
            }}
          >
            <div className="icon">
              <img
                src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7c/Noun_Project_pie_chart_icon_1379121_cc.svg/103px-Noun_Project_pie_chart_icon_1379121_cc.svg.png"
                style={{ width: 50, margin: "20px 0 0 50px" }}
              />
              <hr />
              <h5 style={{ font: "bold", margin: "20px 0 0 45px" }}>
                {summary.transaction_volume}
              </h5>
            </div>
          </fieldset>
          <fieldset
            style={{
              backgroundColor: "white",
              width: 150,
              height: 200,
              borderRadius: 10
            }}
          >
            <div className="icon">
              <h5 style={{ font: "bold", margin: "40px 0 0 65px" }}>
                {summary.new_customers}
              </h5>
              <hr style={{ marginTop: 20 }} />
              <img
                src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9f/New_user_icon-01.svg/512px-New_user_icon-01.svg.png"
                style={{ width: 50, margin: "0px 0 0 50px" }}
              />
            </div>
          </fieldset>
          <fieldset
            style={{
              backgroundColor: "white",
              width: 150,
              height: 200,
              borderRadius: 10
            }}
          >
            <div className="icon">
              <img
                src="https://pics.freeicons.io/uploads/icons/png/8471584441553857633-512.png"
                style={{ width: 50, margin: "20px 0 0 50px" }}
              />
              <hr style={{ marginTop: 12 }} />
              <h5 style={{ font: "bold", margin: "30px 0 0 45px" }}>
                {summary.total_receivable}
              </h5>
            </div>
          </fieldset>
          <fieldset
            style={{
              backgroundColor: "white",
              width: 150,
              height: 200,
              borderRadius: 10
            }}
          >
            <div className="icon">
              <h5 style={{ font: "bold", margin: "40px 0 0 45px" }}>
                {summary.fx_gain}
              </h5>
              <hr style={{ marginTop: 20 }} />
              <img
                src="https://banner2.cleanpng.com/20180203/ode/kisspng-dollar-sign-icon-dpllar-sign-5a75cb480c19c2.8590531415176691920496.jpg"
                style={{ width: 60, margin: "0px 0 0 45px" }}
              />
            </div>
          </fieldset>
          <fieldset
            style={{ backgroundColor: "white", width: 250, height: 200 }}
          />
        </div>
      </div>
      <Chart
        chartType="Bar"
        width="100%"
        height="400px"
        data={(["Value", "Label"], line)}
        options={{
          chart: {
            title: "Total Transaction",
            subtitle: ""
          }
        }}
      />Country:
      <Select style={{ width: 120 }}>
        {drop.map((c) => {
          return <Option value="lucy">{c.label}</Option>;
        })}
      </Select>
      <main style={{ backgroundColor: "rgb(234, 234, 234)" }}>
        <table class="table table-hover">
          <thead>
            <tr>
              <th scope="col">Sender Full Name</th>
              <th scope="col">Receiver Full Name</th>
              <th scope="col">Current Status</th>

              <th scope="col">Send Amount</th>
              <th scope="col">Receive Amount</th>
            </tr>
          </thead>
          <tbody>
            {tran.map((a) => (
              <tr class="table-secondary">
                <td>{a["Sender Full Name"]}</td>
                <td>{a["Receiver Full Name"]}</td>
                <td>{a["Current Status"]}</td>

                <td>{a["Send Amount"]}</td>
                <td>{a["Receive Amount"]}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <hr />
        <table class="table table-hover">
          <thead>
            <tr>
              <th scope="col">ticket_id</th>
              <th scope="col">ticket_category</th>
              <th scope="col">ticket_status</th>

              <th scope="col">ticket_priority</th>
              <th scope="col">assign_to</th>
            </tr>
          </thead>
          <tbody>
            {tic.map((a) => (
              <tr class="table-secondary">
                <td>{a["id"]}</td>
                <td>{a["ticket_category"]}</td>
                <td>{a["ticket_status"]}</td>

                <td>{a["ticket_priority"]}</td>
                <td>{a["assign_to"]}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </main>
    </div>
  );
}
