import axios from "axios";
const apiInstance = axios.create({
  baseURL: "https://jp-dev.cityremit.global/web-api/"
});
export default apiInstance;
